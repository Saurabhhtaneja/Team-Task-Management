package com.example.team_task_manager.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter @Setter
public class LoginRequest {
    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;
}