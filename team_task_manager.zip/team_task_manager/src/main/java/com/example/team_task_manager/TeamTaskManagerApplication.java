package com.example.team_task_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamTaskManagerApplication {
	public static void main(String[] args) {
		SpringApplication.run(TeamTaskManagerApplication.class, args);
	}
}